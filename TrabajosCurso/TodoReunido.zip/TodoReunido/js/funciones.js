var nombreUsuarioSesion = "";
var passwordUsuarioSesion = "";
var correoUsuarioSesion = "";
var fechaNacimientoUsuarioSesion = "";
var ciudadUsuarioSesion = "";

var cantidadUsuarios = 0; 
var numeroUsuario = 0;

var usuarios =  new Array(); 



function ValidarUsuario(){
	var usuario = document.getElementById("usuario").value;
	var contraseña = document.getElementById("password").value;
	var nombre = document.getElementById("NUser");
	if (usuario == "" || contraseña == "") {
		$( "#error" ).html("Digite un usuario o contraseña valida");
	}
	if (usuario == nombreUsuarioSesion || contraseña == passwordUsuarioSesion) {

		IniciarSesion();
	}
}

function RegistroUsuario(){
	var dato = new Array();
	dato[0] = document.getElementById("usuarioRegistro").value;
	dato[1] = document.getElementById("passwordRegistro").value;
	dato[2] = document.getElementById("correoRegistro").value;
	dato[3] = document.getElementById("fechaNacimientoRegistro").value;
	dato[4] = document.getElementById("ciudadRegistro").value;
	
	if (dato[0] == "" || dato[1] == "" || dato[2] == "" || dato[3] == "" || dato[4] == "") {
		$( "#error2" ).html("Digite todos los campos");
	}else {
		numeroUsuario++;
		cantidadUsuarios+1;	
		for (var i = 0; i < 6; i++) {
			usuarios[numeroUsuario][i] = dato[i];
			if (i == 5) {
				usuarios[numeroUsuario][i] = numeroUsuario;
			}
		}
		console.log(dato[3]);
		IniciarSesion();
	}
	
}

function IniciarSesion(){
	document.getElementById("menu").style.display = "block";
	document.getElementById("nav1").style.display = "none";
	document.getElementById("login").style.display = "none";

	nombre.innerHTML = "<a>" + nombreUsuario + "</a>";
}
